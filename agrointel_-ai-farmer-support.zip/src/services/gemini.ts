import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeCropDisease(base64Image: string, language: 'en' | 'ta' = 'en') {
  const languageName = language === 'en' ? 'English' : 'Tamil';
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image,
            },
          },
          {
            text: `Analyze this crop image in ${languageName}. 
            
            First, identify the plant. 
            Then, perform a dual analysis for:
            1. **Potential Diseases** (fungal, bacterial, viral, etc.)
            2. **Potential Pests** (insects, larvae, mites, etc.)

            If either diseases or pests are detected, provide a detailed report including:
            - **Identification**: Name of the disease or pest.
            - **Symptoms/Signs**: Specific visual evidence in the image.
            - **Severity**: Low, Moderate, or High.
            - **Organic Treatment**: Natural remedies or cultural practices.
            - **Chemical Treatment**: Recommended pesticides or fungicides if necessary.
            - **Prevention**: How to avoid this in the future.

            If the plant is healthy, state that clearly and provide optimal maintenance tips.
            
            Format the output in clean, professional Markdown with clear headers and bullet points.`,
          },
        ],
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("Failed to analyze crop image.");
  }
}

export async function analyzeSoilImage(base64Image: string, language: 'en' | 'ta' = 'en') {
  const languageName = language === 'en' ? 'English' : 'Tamil';
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image,
            },
          },
          {
            text: `Analyze this soil image. Estimate its health based on color, texture, and visible components (like organic matter, rocky bits, or moisture). Provide a report in ${languageName}.
Include:
1. Visual Observations
2. Estimated Soil Type (clay, sandy, loamy, etc.)
3. Apparent Health Status
4. General recommendations for this soil type.
Format the output in clear Markdown with bold headers. Disclaimer: This is a visual estimate, not a lab result.`,
          },
        ],
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Soil Image Analysis Error:", error);
    throw new Error("Failed to analyze soil image.");
  }
}

export async function identifyCropFromImage(base64Image: string, language: 'en' | 'ta' = 'en') {
  const languageName = language === 'en' ? 'English' : 'Tamil';
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image,
            },
          },
          {
            text: `Identify the main agricultural crop in this image. Return ONLY the name of the crop in ${languageName}. Do not include any other text or explanation.`,
          },
        ],
      },
    });
    return response.text.trim();
  } catch (error) {
    console.error("Gemini Crop Identification Error:", error);
    throw new Error("Failed to identify crop.");
  }
}

export async function getSoilRecommendation(params: {
  ph: string;
  nitrogen: string;
  phosphorus: string;
  potassium: string;
  moisture: string;
  location: string;
}, language: 'en' | 'ta' = 'en') {
  const languageName = language === 'en' ? 'English' : 'Tamil';
  try {
    const prompt = `Based on these soil parameters:
- pH: ${params.ph}
- Nitrogen (N): ${params.nitrogen}
- Phosphorus (P): ${params.phosphorus}
- Potassium (K): ${params.potassium}
- Moisture: ${params.moisture}%
- Location: ${params.location}

Provide a detailed soil analysis and crop recommendation in ${languageName}. 
Include:
1. Soil Health Status
2. Best Crops to grow in these conditions
3. Fertilizer recommendations to balance NPK
4. Irrigation suggestions
Format the output in clear Markdown with bold headers.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Soil Analysis Error:", error);
    throw new Error("Failed to provide soil recommendations.");
  }
}

export async function getMarketInsights(query: string, language: 'en' | 'ta' = 'en') {
  const languageName = language === 'en' ? 'English' : 'Tamil';
  try {
    const prompt = `Act as an Agribusiness Analyst. Analyze the following market query and provide a detailed response in ${languageName}: "${query}"

Include detailed sections for:
1. **Market Sentiment & Overview**: Current "vibe" of the market for the mentioned commodities.
2. **Price Trend Prediction**: Forecast for the next 4-8 weeks based on current data.
3. **Comparative Analysis**: If multiple commodities are mentioned, compare their relative performance.
4. **Actionable Strategic Advice**: Specific recommendations for farmers regarding harvest timing, storage, or diversification.
5. **Key Risk Factors**: Weather, geopolitical, or logistical issues that could shift the market.

Format the output in professional Markdown with bold headers and bullet points. Use tables for comparisons if relevant.`;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Market Insight Error:", error);
    throw new Error("Failed to fetch market insights.");
  }
}
