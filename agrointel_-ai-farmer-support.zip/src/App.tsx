/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Sprout, 
  ThermometerSun, 
  TrendingUp, 
  FlaskConical, 
  Menu, 
  X,
  ChevronRight,
  CloudRain,
  Wind,
  Droplets,
  MapPin,
  Clock,
  Languages
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { translations, type Language } from './lib/i18n';

// Helper for tailwind class merging
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Components
import { DiseaseDetector } from './components/DiseaseDetector';
import { SoilAdvisor } from './components/SoilAdvisor';
import { MarketHub } from './components/MarketHub';
import { WeatherWidget } from './components/WeatherWidget';

type Tab = 'dashboard' | 'disease' | 'soil' | 'market';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [language, setLanguage] = useState<Language>('en');

  const t = translations[language];

  const navItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'disease', label: t.cropHealth, icon: Sprout },
    { id: 'soil', label: t.soilInsight, icon: FlaskConical },
    { id: 'market', label: t.marketHub, icon: TrendingUp },
  ] as const;

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-green-100 selection:text-green-900">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-white border-b border-gray-200">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
            <Sprout className="text-white w-5 h-5" />
          </div>
          <span className="font-bold text-xl tracking-tight">{t.appName}</span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
            className="p-2 hover:bg-gray-100 rounded-full text-green-600"
          >
            <Languages className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-md"
          >
            {isSidebarOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      <div className="flex h-[calc(100vh-65px)] lg:h-screen overflow-hidden">
        {/* Sidebar */}
        <AnimatePresence mode="wait">
          {isSidebarOpen && (
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              className={cn(
                "fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-gray-200 lg:relative flex flex-col",
                !isSidebarOpen && "hidden lg:flex"
              )}
            >
              <div className="p-6 flex items-center gap-3">
                <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-200">
                  <Sprout className="text-white w-6 h-6" />
                </div>
                <div>
                  <h1 className="font-black text-2xl leading-none tracking-tighter">{t.appName}</h1>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-gray-400 mt-1">{t.tagline}</p>
                </div>
              </div>

              <nav className="flex-1 px-4 py-4 space-y-1">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      if (window.innerWidth < 1024) setIsSidebarOpen(false);
                    }}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden",
                      activeTab === item.id 
                        ? "bg-green-50 text-green-700 font-semibold" 
                        : "text-gray-500 hover:bg-gray-50 hover:text-gray-900"
                    )}
                  >
                    {activeTab === item.id && (
                      <motion.div 
                        layoutId="nav-active" 
                        className="absolute left-0 w-1 h-6 bg-green-600 rounded-full" 
                      />
                    )}
                    <item.icon className={cn("w-5 h-5", activeTab === item.id ? "text-green-600" : "group-hover:scale-110 transition-transform")} />
                    <span>{item.label}</span>
                    {activeTab === item.id && <ChevronRight className="ml-auto w-4 h-4 opacity-50" />}
                  </button>
                )) as any}
              </nav>

              <div className="p-4 border-t border-gray-100 space-y-4">
                <button 
                  onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
                  className="w-full flex items-center justify-between p-4 bg-gray-50 hover:bg-green-50 rounded-2xl transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <Languages className="w-5 h-5 text-gray-400 group-hover:text-green-600" />
                    <span className="text-sm font-bold text-gray-600">{language === 'en' ? 'தமிழ்' : 'English'}</span>
                  </div>
                  <div className="text-[10px] font-black uppercase text-gray-300">Switch</div>
                </button>
                <div className="px-2 text-[10px] text-gray-400 font-medium text-center italic">
                  © 2026 AgroIntel Systems v1.1
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-[#F8F9FA] relative">
          <div className="max-w-6xl mx-auto p-4 lg:p-8">
            <AnimatePresence mode="wait">
              {activeTab === 'dashboard' && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 py-4">
                    <div>
                      <h2 className="text-3xl font-black tracking-tight text-gray-900">{t.goodMorning}</h2>
                      <p className="text-gray-500 font-medium mt-1">{t.dailySummary}</p>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-bold bg-white px-4 py-2 rounded-full border border-gray-200 shadow-sm">
                      <Clock className="w-4 h-4 text-green-600" />
                      {new Date().toLocaleDateString(language === 'en' ? 'en-US' : 'ta-IN', { weekday: 'long', month: 'long', day: 'numeric' })}
                    </div>
                  </header>

                  {/* Summary Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <WeatherWidget language={language} />
                    <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow group">
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                            <Droplets className="text-blue-500 w-6 h-6" />
                          </div>
                          <span className="text-xs font-black text-gray-300 uppercase tracking-widest">{t.weather.humidity}</span>
                        </div>
                        <h3 className="text-2xl font-black text-gray-900">{t.summary.moistureStatus}</h3>
                        <p className="text-sm text-gray-500 mt-1 font-medium">{t.summary.moistureDetail}</p>
                      </div>
                      <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow group">
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center group-hover:bg-amber-100 transition-colors">
                            <TrendingUp className="text-amber-500 w-6 h-6" />
                          </div>
                          <span className="text-xs font-black text-gray-300 uppercase tracking-widest">{t.marketHub}</span>
                        </div>
                        <h3 className="text-2xl font-black text-gray-900">{t.summary.marketChange}</h3>
                        <p className="text-sm text-gray-500 mt-1 font-medium">{t.summary.marketDetail}</p>
                      </div>
                    </div>
                  </div>

                  {/* Activity/Alerts */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <section className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-sm">
                      <h3 className="text-xl font-black mb-6 flex items-center gap-2">
                         <div className="w-2 h-6 bg-green-600 rounded-full" />
                         {t.recentChecks}
                      </h3>
                      <div className="space-y-4">
                        {[1, 2].map((i) => (
                          <div key={i} className="flex items-center gap-4 p-4 rounded-3xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100">
                            <div className="w-16 h-16 bg-gray-100 rounded-2xl overflow-hidden shrink-0">
                               <img 
                                src={`https://images.unsplash.com/photo-1597362905298-2514332906e5?auto=format&fit=crop&q=80&w=200`} 
                                alt="Leaf" 
                                className="w-full h-full object-cover grayscale opacity-50"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-900">{t.summary.tomatoCheck}</h4>
                              <p className="text-xs text-gray-500 font-medium italic">{t.summary.checkStatus}</p>
                            </div>
                            <ChevronRight className="text-gray-300 w-5 h-5" />
                          </div>
                        ))}
                      </div>
                    </section>

                    <section className="bg-[#1A1A1A] p-8 rounded-[40px] text-white shadow-xl">
                      <div className="flex justify-between items-start mb-6">
                        <h3 className="text-xl font-black tracking-tight">{t.aiTip}</h3>
                        <div className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-green-500/30">
                          {t.exclusiveInsight}
                        </div>
                      </div>
                      <p className="text-gray-400 text-lg leading-relaxed font-medium">
                        {t.summary.aiTipContent}
                      </p>
                      <button className="mt-8 text-sm font-black flex items-center gap-2 text-green-400 hover:text-green-300 transition-colors uppercase tracking-widest">
                        {t.learnMore} <ChevronRight className="w-4 h-4" />
                      </button>
                    </section>
                  </div>
                </motion.div>
              )}

              {activeTab === 'disease' && <DiseaseDetector language={language} />}
              {activeTab === 'soil' && <SoilAdvisor language={language} />}
              {activeTab === 'market' && <MarketHub language={language} />}
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}

