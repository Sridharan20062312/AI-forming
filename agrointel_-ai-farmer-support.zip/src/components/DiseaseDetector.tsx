import React, { useState, useRef } from 'react';
import { Camera, Upload, Trash2, ShieldCheck, AlertCircle, Loader2, RefreshCw, Sprout, Bug } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { analyzeCropDisease } from '../services/gemini';
import { translations, type Language } from '../lib/i18n';

interface DiseaseDetectorProps {
  language: Language;
}

export function DiseaseDetector({ language }: DiseaseDetectorProps) {
  const t = translations[language].diagnostic;
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const base64Data = image.split(',')[1];
      const analysisResult = await analyzeCropDisease(base64Data, language);
      setResult(analysisResult || 'No analysis could be generated.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during analysis.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setError(null);
    setIsAnalyzing(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="max-w-4xl mx-auto space-y-8"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-gray-200 pb-6">
        <div>
          <h2 className="text-4xl font-black tracking-tighter text-gray-900 uppercase">{t.title}</h2>
          <p className="text-gray-500 font-medium mt-1">{t.subtitle}</p>
        </div>
        {image && (
          <button 
            onClick={reset}
            className="flex items-center gap-2 px-4 py-2 text-sm font-black text-gray-500 hover:text-red-500 transition-colors uppercase tracking-widest border border-gray-200 rounded-xl bg-white"
          >
            <Trash2 className="w-4 h-4" /> {language === 'en' ? 'Start Over' : 'மீண்டும் தொடங்கு'}
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 h-full items-start">
        {/* Upload Section */}
        <section className="space-y-6">
          {!image ? (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="group aspect-[4/3] rounded-[40px] border-4 border-dashed border-gray-200 bg-white flex flex-col items-center justify-center gap-6 cursor-pointer hover:border-green-400 hover:bg-green-50/30 transition-all duration-300"
            >
              <div className="w-24 h-24 bg-gray-100 rounded-3xl flex items-center justify-center group-hover:bg-green-100 group-hover:scale-110 transition-all">
                <Camera className="w-10 h-10 text-gray-400 group-hover:text-green-600" />
              </div>
              <div className="text-center">
                <p className="text-xl font-black text-gray-900">{t.uploadTitle}</p>
                <p className="text-sm font-medium text-gray-400 mt-2 italic px-8">{t.uploadSubtitle}</p>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileChange} 
                className="hidden" 
                accept="image/*"
              />
            </div>
          ) : (
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="relative aspect-[4/3] rounded-[40px] overflow-hidden border-4 border-white shadow-2xl bg-gray-200 group"
            >
              <img 
                src={image} 
                alt="Upload preview" 
                className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-700" 
              />
              <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
                {!isAnalyzing && !result && (
                  <button 
                    onClick={handleAnalyze}
                    className="w-full bg-green-500 hover:bg-green-400 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 shadow-lg shadow-green-900/20 transition-all uppercase tracking-widest text-lg"
                  >
                    <ShieldCheck className="w-6 h-6" /> {t.runDiagnostic}
                  </button>
                )}
              </div>
            </motion.div>
          )}

          <div className="bg-amber-50 border border-amber-200 p-6 rounded-3xl flex gap-4">
            <AlertCircle className="w-6 h-6 text-amber-600 shrink-0" />
            <div>
              <p className="text-sm font-black text-amber-900 uppercase tracking-widest">{t.accuracyNotice}</p>
              <p className="text-xs font-medium text-amber-700 mt-1">{t.accuracyText}</p>
            </div>
          </div>
        </section>

        {/* Results Section */}
        <section className="h-full min-h-[400px]">
          <AnimatePresence mode="wait">
            {isAnalyzing && (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center h-full gap-6 bg-white rounded-[40px] border border-gray-100 p-12 text-center"
              >
                <div className="relative">
                  <Loader2 className="w-16 h-16 text-green-600 animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-ping" />
                  </div>
                </div>
                <div>
                  <h4 className="text-2xl font-black text-gray-900">{t.analyzing}</h4>
                  <p className="text-gray-400 font-medium mt-2">{t.checking}</p>
                </div>
              </motion.div>
            )}

            {result && (
              <motion.div 
                key="result"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[40px] border border-gray-100 shadow-xl overflow-hidden flex flex-col h-full"
              >
                <div className="p-6 bg-green-600 text-white flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex -space-x-2">
                      <ShieldCheck className="w-6 h-6" />
                      <Bug className="w-6 h-6 text-green-200" />
                    </div>
                    <span className="font-black uppercase tracking-widest">{t.reportTitle}</span>
                  </div>
                  <button 
                    onClick={handleAnalyze} 
                    className="p-2 hover:bg-white/20 rounded-lg transition-colors border border-white/20"
                    title="Re-analyze"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                </div>
                <div className="p-8 overflow-y-auto max-h-[600px] prose prose-green prose-sm max-w-none">
                   <div className="markdown-body">
                    <ReactMarkdown>{result}</ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            )}

            {!isAnalyzing && !result && !error && (
              <div className="h-full flex flex-col items-center justify-center bg-gray-50 rounded-[40px] border-2 border-dashed border-gray-200 p-12 text-center text-gray-400">
                <Sprout className="w-16 h-16 opacity-20 mb-4" />
                <p className="font-black uppercase tracking-widest text-sm">{t.emptyState}</p>
              </div>
            )}

            {error && (
               <motion.div 
                key="error"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-8 bg-red-50 border border-red-100 rounded-[40px] h-full flex flex-col items-center justify-center text-center text-red-600"
              >
                <AlertCircle className="w-12 h-12 mb-4" />
                <p className="font-black text-xl">Analysis Failed</p>
                <p className="text-sm mt-1 mb-6 font-medium">{error}</p>
                <button 
                  onClick={handleAnalyze}
                  className="px-6 py-3 bg-red-600 text-white font-black rounded-2xl uppercase tracking-widest text-xs hover:bg-red-700 transition-colors"
                >
                  Try Again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </div>

      {/* Common Solutions Grid */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[40px] border border-gray-100 p-8 shadow-sm mt-8"
      >
        <div className="mb-6">
          <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2">
            <ShieldCheck className="text-green-600 w-5 h-5" /> {t.commonSolutions}
          </h3>
          <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">{t.commonSolutionsSub}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {(t as any).solutions?.map((sol: any, idx: number) => (
            <div key={idx} className="p-6 bg-gray-50 rounded-3xl border border-transparent hover:border-green-100 transition-all hover:bg-white hover:shadow-lg group">
              <h4 className="font-black text-gray-900 group-hover:text-green-600 transition-colors">{sol.title}</h4>
              <p className="text-[10px] font-black uppercase text-amber-600 mt-1 tracking-widest">{sol.symptom}</p>
              <div className="mt-4 p-3 bg-white rounded-xl border border-gray-100 text-sm font-medium text-gray-600 shadow-sm">
                <span className="text-[10px] font-black text-green-600 uppercase block mb-1">{t.solutionTag}</span>
                {sol.fix}
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}
