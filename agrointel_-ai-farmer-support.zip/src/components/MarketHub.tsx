import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  Search, 
  ArrowUpRight, 
  ArrowDownRight, 
  Globe, 
  Calendar,
  ChevronRight,
  Loader2,
  Zap,
  Layers,
  LineChart as LineChartIcon,
  Info,
  Camera,
  Upload,
  Trash2,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  Brush
} from 'recharts';
import { getMarketInsights, identifyCropFromImage } from '../services/gemini';
import { translations, type Language } from '../lib/i18n';

const HISTORICAL_DATA = {
  weekly: [
    { label: 'W1', wheat: 7.2, corn: 4.1, rice: 17.8, soybeans: 11.9, avg: 10.25 },
    { label: 'W2', wheat: 7.4, corn: 4.3, rice: 18.1, soybeans: 12.1, avg: 10.48 },
    { label: 'W3', wheat: 7.3, corn: 4.2, rice: 18.4, soybeans: 12.0, avg: 10.48 },
    { label: 'W4', wheat: 7.5, corn: 4.5, rice: 18.2, soybeans: 12.4, avg: 10.65 },
    { label: 'W5', wheat: 7.8, corn: 4.6, rice: 18.5, soybeans: 12.6, avg: 10.88 },
    { label: 'W6', wheat: 7.6, corn: 4.4, rice: 18.3, soybeans: 12.5, avg: 10.70 },
  ],
  monthly: [
    { label: 'May', wheat: 6.8, corn: 3.9, rice: 16.5, soybeans: 11.5, avg: 9.68 },
    { label: 'Jun', wheat: 6.5, corn: 4.1, rice: 16.8, soybeans: 11.2, avg: 9.65 },
    { label: 'Jul', wheat: 7.2, corn: 4.3, rice: 17.2, soybeans: 11.8, avg: 10.13 },
    { label: 'Aug', wheat: 7.5, corn: 4.0, rice: 17.5, soybeans: 12.1, avg: 10.28 },
    { label: 'Sep', wheat: 7.1, corn: 3.8, rice: 17.9, soybeans: 11.9, avg: 10.18 },
    { label: 'Oct', wheat: 7.4, corn: 4.2, rice: 18.2, soybeans: 12.3, avg: 10.53 },
    { label: 'Nov', wheat: 7.8, corn: 4.5, rice: 18.0, soybeans: 12.7, avg: 10.75 },
    { label: 'Dec', wheat: 8.1, corn: 4.4, rice: 18.3, soybeans: 12.9, avg: 10.93 },
    { label: 'Jan', wheat: 7.9, corn: 4.1, rice: 18.5, soybeans: 12.6, avg: 10.78 },
    { label: 'Feb', wheat: 7.6, corn: 4.3, rice: 18.4, soybeans: 12.4, avg: 10.68 },
    { label: 'Mar', wheat: 7.4, corn: 4.2, rice: 18.1, soybeans: 12.2, avg: 10.48 },
    { label: 'Apr', wheat: 7.42, corn: 4.28, rice: 18.40, soybeans: 12.15, avg: 10.56 },
  ],
  quarterly: [
    { label: 'Q1', wheat: 7.5, corn: 4.2, rice: 18.0, soybeans: 12.1, avg: 10.45 },
    { label: 'Q2', wheat: 7.8, corn: 4.4, rice: 18.3, soybeans: 12.4, avg: 10.73 },
    { label: 'Q3', wheat: 7.2, corn: 4.1, rice: 17.5, soybeans: 11.9, avg: 10.18 },
    { label: 'Q4', wheat: 7.9, corn: 4.5, rice: 18.5, soybeans: 12.8, avg: 10.93 },
  ]
};

function SentimentGauge({ score, language }: { score: number; language: Language }) {
  // score is 0 to 100
  const rotation = (score / 100) * 180 - 90;
  
  let label = "Neutral";
  let color = "text-amber-500";
  let bgColor = "bg-amber-500";
  
  if (score > 70) {
    label = language === 'en' ? "Bullish" : "உயர்வு";
    color = "text-green-500";
    bgColor = "bg-green-500";
  } else if (score < 40) {
    label = language === 'en' ? "Bearish" : "வீழ்ச்சி";
    color = "text-red-500";
    bgColor = "bg-red-500";
  } else {
    label = language === 'en' ? "Neutral" : "சமநிலை";
  }

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-32 h-16 overflow-hidden">
        {/* Gauge Track */}
        <div className="absolute top-0 left-0 w-32 h-32 rounded-full border-[10px] border-gray-100" />
        {/* Gauge Colors */}
        <div className="absolute top-0 left-0 w-32 h-32 rounded-full border-[12px] border-transparent border-t-red-500/20 border-l-red-500/20 rotate-[-45deg]" />
        <div className="absolute top-0 left-0 w-32 h-32 rounded-full border-[12px] border-transparent border-t-green-500/20 border-r-green-500/20 rotate-[45deg]" />
        
        {/* Needle */}
        <motion.div 
          className="absolute bottom-0 left-1/2 w-1 h-14 bg-gray-800 origin-bottom rounded-full z-10"
          initial={{ rotate: -90 }}
          animate={{ rotate: rotation }}
          transition={{ type: 'spring', stiffness: 60, damping: 15 }}
          style={{ translateX: '-50%' }}
        />
        <div className="absolute bottom-0 left-1/2 w-4 h-4 bg-gray-800 rounded-full z-20 -translate-x-1/2 translate-y-1/2" />
      </div>
      <div className="text-center">
        <span className={`text-[10px] font-black uppercase tracking-widest ${color}`}>{label}</span>
        <div className="flex items-center gap-1 mt-1 justify-center">
          <div className={`w-1.5 h-1.5 rounded-full ${bgColor} animate-pulse`} />
          <span className="text-lg font-black text-gray-900 leading-none">{score}%</span>
        </div>
      </div>
    </div>
  );
}

interface MarketHubProps {
  language: Language;
}

const COMMODITIES_EN = [
  { id: 'wheat', name: 'Wheat', price: '$7.42', change: '+2.4%', color: 'bg-amber-500', sentiment: 75 },
  { id: 'corn', name: 'Corn', price: '$4.28', change: '-1.1%', color: 'bg-yellow-500', sentiment: 42 },
  { id: 'soybeans', name: 'Soybeans', price: '$12.15', change: '+0.5%', color: 'bg-green-500', sentiment: 58 },
  { id: 'rice', name: 'Rice', price: '$18.40', change: '+3.2%', color: 'bg-blue-300', sentiment: 88 },
  { id: 'coffee', name: 'Coffee', price: '$1.85', change: '-0.8%', color: 'bg-stone-700', sentiment: 35 },
];

const COMMODITIES_TA = [
  { id: 'wheat', name: 'கோதுமை', price: '$7.42', change: '+2.4%', color: 'bg-amber-500', sentiment: 75 },
  { id: 'corn', name: 'சோளம்', price: '$4.28', change: '-1.1%', color: 'bg-yellow-500', sentiment: 42 },
  { id: 'soybeans', name: 'சோயாபீன்ஸ்', price: '$12.15', change: '+0.5%', color: 'bg-green-500', sentiment: 58 },
  { id: 'rice', name: 'அரிசி', price: '$18.40', change: '+3.2%', color: 'bg-blue-300', sentiment: 88 },
  { id: 'coffee', name: 'காபி', price: '$1.85', change: '-0.8%', color: 'bg-stone-700', sentiment: 35 },
];

const CustomTooltip = ({ active, payload, label, language }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-5 rounded-[24px] shadow-2xl border border-gray-100 min-w-[220px]">
        <div className="flex items-center justify-between mb-3 border-b border-gray-50 pb-2">
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
            {label}
          </p>
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
        </div>
        <div className="space-y-2.5">
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color || entry.stroke }} />
                <span className="text-[10px] font-black text-gray-500 uppercase tracking-tight">{entry.name}</span>
              </div>
              <span className="text-sm font-black text-gray-900">${typeof entry.value === 'number' ? entry.value.toFixed(2) : entry.value}</span>
            </div>
          ))}
        </div>
        <p className="text-[8px] font-bold text-gray-300 mt-3 uppercase tracking-widest text-center">
          {language === 'en' ? 'Click to focus' : 'கவனம் செலுத்த கிளிக் செய்க'}
        </p>
      </div>
    );
  }
  return null;
};

export function MarketHub({ language }: MarketHubProps) {
  const t = translations[language].market;
  const COMMODITIES = language === 'en' ? COMMODITIES_EN : COMMODITIES_TA;
  const [query, setQuery] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [insight, setInsight] = useState<string | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [sentimentScore, setSentimentScore] = useState<number>(50);
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly' | 'quarterly'>('monthly');
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const uploadInputRef = React.useRef<HTMLInputElement>(null);

  const SUGGESTED_QUERIES = language === 'en' ? [
    "Will wheat prices rise next quarter?",
    "Impact of El Niño on rice yields",
    "Best time to sell stored corn",
    "Fertilizer cost forecast 2026",
    "Drought impact on organic barley",
    "Global soybean supply trends"
  ] : [
    "அடுத்த காலாண்டில் கோதுமை விலை உயருமா?",
    "அரிசி விளைச்சலில் எல் நினோ தாக்கம்",
    "சேமிக்கப்பட்ட சோளத்தை விற்க சிறந்த நேரம்",
    "உர செலவு முன்னறிவிப்பு 2026",
    "பார்லி மீதான வறட்சி தாக்கம்",
    "உலகளாவிய சோயாபீன் விநியோக போக்குகள்"
  ];

  // Basic fuzzy/flexible ignore-case filter
  const getFilteredSuggestions = () => {
    const term = query.toLowerCase().trim();
    if (!term) return SUGGESTED_QUERIES.slice(0, 4);

    // Filter commodities
    const matchedCommodities = COMMODITIES.filter(c => 
      c.name.toLowerCase().includes(term) || 
      term.includes(c.name.toLowerCase())
    );

    // If typing "compare", suggest multi-commodity comparisons
    if (term.includes('compare') || term.includes('vs')) {
      return language === 'en' 
        ? ["Wheat vs Corn trends", "Rice and Soybeans comparison", "Barley vs Wheat price predictive analysis"]
        : ["கோதுமை மற்றும் சோளம் ஒப்பீடு", "அரிசி மற்றும் சோயாபீன்ஸ் ஒப்பீடு", "பார்லி மற்றும் கோதுமை விலை கணிப்பு"];
    }

    const commodities = matchedCommodities.map(c => 
      language === 'en' ? `Price analysis for ${c.name}` : `${c.name} விலை பகுப்பாய்வு`
    );

    const queries = SUGGESTED_QUERIES.filter(q => 
      q.toLowerCase().includes(term)
    );

    const combined = [...commodities, ...queries];
    return combined.length > 0 ? combined : SUGGESTED_QUERIES.slice(0, 3);
  };

  const filteredSuggestions = getFilteredSuggestions();

  const fetchInsights = async (topic: string) => {
    setIsAnalyzing(true);
    setSelectedTopic(topic);
    setQuery(topic);
    setShowSuggestions(false);
    
    // Find if it's one of our predefined commodities to get its sentiment
    const commod = COMMODITIES.find(c => c.name === topic || topic.toLowerCase().includes(c.name.toLowerCase()));
    setSentimentScore(commod ? (commod as any).sentiment : Math.floor(Math.random() * (90 - 30) + 30));
    
    try {
      const data = await getMarketInsights(topic, language);
      setInsight(data || 'No data found.');
    } catch (err) {
      setInsight('Failed to fetch market data.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCameraClick = () => {
    fileInputRef.current?.click();
  };

  const handleUploadClick = () => {
    uploadInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);
    setInsight(null);
    setShowSuggestions(false);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        try {
          const cropName = await identifyCropFromImage(base64Data, language);
          if (cropName) {
            setQuery(cropName);
            await fetchInsights(cropName);
          }
        } catch (err) {
          console.error("Scan error:", err);
          setInsight(language === 'en' ? "Could not identify crop from image." : "படத்திலிருந்து பயிரை அடையாளம் காண முடியவில்லை.");
        } finally {
          setIsScanning(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error(err);
      setIsScanning(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="max-w-6xl mx-auto space-y-8"
    >
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-gray-200 pb-6">
        <div>
          <h2 className="text-4xl font-black tracking-tighter text-gray-900 uppercase">{t.title}</h2>
          <p className="text-gray-500 font-medium mt-1">{t.subtitle}</p>
        </div>
        <div className="flex items-center gap-2 text-xs font-black bg-white border border-gray-200 px-4 py-2 rounded-xl shadow-sm uppercase tracking-widest text-gray-400">
          <Globe className="w-3 h-3" /> {language === 'en' ? 'Global Feeds Live' : 'நேரடி உலகளாவிய தகவல்கள்'}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar: Commodity Quick List */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-sm font-black text-gray-400 uppercase tracking-widest mb-4">{t.popular}</h3>
          {COMMODITIES.map((c) => (
            <button
              key={c.id}
              onClick={() => fetchInsights(c.name)}
              className="w-full bg-white border border-gray-100 p-4 rounded-3xl flex items-center justify-between hover:shadow-md hover:border-gray-200 transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 ${c.color} rounded-lg flex items-center justify-center shrink-0`}>
                  <TrendingUp className="text-white w-4 h-4" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-black text-gray-900">{c.name}</p>
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-tight">{language === 'en' ? 'Last 24h' : 'கடந்த 24 மணிநேரம்'}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-gray-900">{c.price}</p>
                <p className={`text-[10px] font-black ${c.change.startsWith('+') ? 'text-green-500' : 'text-red-500'}`}>
                  {c.change}
                </p>
              </div>
            </button>
          ))}
          
          <div className="bg-[#1A1A1A] text-white p-6 rounded-[32px] mt-8">
            <h4 className="text-sm font-black uppercase tracking-widest mb-2 text-amber-400">{t.alertTitle}</h4>
            <p className="text-xs font-medium text-gray-400 leading-relaxed uppercase tracking-tighter">
              {language === 'en' 
                ? 'Logistics interruptions in the Black Sea region may impact wheat exports next week.' 
                : 'பிளாக் சீ பிராந்தியத்தில் லாஜிஸ்டிக்ஸ் இடையூறுகள் அடுத்த வாரம் கோதுமை ஏற்றுமதியை பாதிக்கலாம்.'}
            </p>
          </div>
        </div>

        {/* Main Insight Engine */}
        <div className="lg:col-span-3 space-y-6">
          {/* Search Bar */}
          <div className="relative group z-30">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-green-600 transition-colors" />
            <input 
              type="text" 
              placeholder={t.searchPlaceholder}
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => setShowSuggestions(true)}
              onKeyDown={(e) => e.key === 'Enter' && fetchInsights(query)}
              className="w-full bg-white border-2 border-transparent focus:border-green-600 p-6 pl-16 pr-32 rounded-[32px] shadow-sm text-lg font-bold outline-none transition-all placeholder:text-gray-300"
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 flex gap-2">
              <button 
                onClick={handleUploadClick}
                disabled={isScanning || isAnalyzing}
                className="bg-gray-100 text-gray-500 p-3 rounded-2xl hover:bg-gray-200 transition-colors shadow-sm disabled:opacity-50"
                title={t.uploadImage}
              >
                <Upload className="w-6 h-6" />
              </button>
              <button 
                onClick={handleCameraClick}
                disabled={isScanning || isAnalyzing}
                className="bg-gray-100 text-gray-500 p-3 rounded-2xl hover:bg-gray-200 transition-colors shadow-sm disabled:opacity-50"
                title={t.scanCrop}
              >
                {isScanning ? <Loader2 className="w-6 h-6 animate-spin" /> : <Camera className="w-6 h-6" />}
              </button>
              <button 
                onClick={() => fetchInsights(query)}
                disabled={isScanning || isAnalyzing}
                className="bg-green-600 text-white p-3 rounded-2xl hover:bg-green-700 transition-colors shadow-lg shadow-green-200 disabled:opacity-50"
              >
                <ArrowUpRight className="w-6 h-6" />
              </button>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*" 
              capture="environment"
            />
            <input 
              type="file" 
              ref={uploadInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*" 
            />

            {/* Suggestions Dropdown */}
            <AnimatePresence>
              {showSuggestions && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute inset-x-0 top-full mt-2 bg-white rounded-[32px] shadow-2xl border border-gray-100 overflow-hidden z-40"
                >
                  <div className="p-4 bg-gray-50 border-b border-gray-100">
                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">{t.suggestions}</p>
                  </div>
                  <div className="max-h-64 overflow-y-auto">
                    {filteredSuggestions.length > 0 ? (
                      filteredSuggestions.map((s, i) => (
                        <button
                          key={i}
                          onClick={() => fetchInsights(s)}
                          className="w-full text-left px-6 py-4 hover:bg-green-50 flex items-center gap-4 group transition-colors"
                        >
                          <Zap className="w-4 h-4 text-gray-300 group-hover:text-green-500 transition-colors" />
                          <span className="font-bold text-gray-700 group-hover:text-green-900">{s}</span>
                          <ChevronRight className="ml-auto w-4 h-4 text-gray-200 group-hover:text-green-400" />
                        </button>
                      ))
                    ) : (
                      <div className="p-8 text-center text-gray-400 font-medium italic">
                        No specific suggestions found. Press Enter to analyze.
                      </div>
                    )}
                  </div>
                  {showSuggestions && (
                    <div 
                      className="fixed inset-0 z-[-1]" 
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowSuggestions(false);
                      }} 
                    />
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <AnimatePresence mode="wait">
            {isAnalyzing ? (
              <motion.div 
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-white rounded-[40px] border border-gray-100 p-20 flex flex-col items-center justify-center text-center gap-6"
              >
                <div className="relative">
                  <Loader2 className="w-16 h-16 text-amber-500 animate-spin" />
                  <TrendingUp className="absolute inset-0 m-auto w-6 h-6 text-amber-400 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-2xl font-black uppercase tracking-tighter">{t.analyzing}</h4>
                  <p className="text-gray-400 font-medium max-w-sm">{t.analyzingSub}</p>
                </div>
              </motion.div>
            ) : insight ? (
              <motion.div 
                key="insight"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-[40px] border border-gray-100 shadow-xl overflow-hidden"
              >
                <div className="p-8 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center shadow-inner">
                      <Zap className="text-amber-500 w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-gray-900 uppercase tracking-tighter leading-none">{selectedTopic} {t.insightTitle}</h4>
                      <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest italic flex items-center gap-1">
                        <Info className="w-3 h-3" /> AI Market Intelligence
                      </p>
                    </div>
                  </div>
                  
                  {/* Market Sentiment Gauge */}
                  <div className="bg-white p-4 rounded-3xl border border-gray-200/60 shadow-sm flex items-center gap-6">
                    <div className="h-full w-[1px] bg-gray-100 mx-2" />
                    <SentimentGauge score={sentimentScore} language={language} />
                  </div>
                </div>
                <div className="p-8 prose prose-amber max-w-none prose-sm">
                  <div className="markdown-body text-gray-700 leading-relaxed">
                    <ReactMarkdown>{insight}</ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-8 rounded-[40px] border border-gray-100 flex flex-col items-center justify-center text-center group hover:border-amber-200 transition-colors">
                  <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mb-6 group-hover:bg-amber-100 transition-colors">
                    <Calendar className="w-8 h-8 text-amber-500" />
                  </div>
                  <h5 className="font-black text-gray-900 uppercase tracking-widest text-xs">Dynamic Intelligence</h5>
                  <p className="text-gray-400 text-sm mt-2 max-w-[200px]">Ask about pricing, weather impacts, or supply chain shifts.</p>
                </div>
                <div className="bg-[#1A1A1A] p-8 rounded-[40px] border border-gray-800 flex flex-col items-center justify-center text-center group hover:bg-black transition-colors">
                  <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-6 group-hover:bg-white/10 transition-colors">
                    <TrendingUp className="w-8 h-8 text-green-400" />
                  </div>
                  <h5 className="font-black text-white uppercase tracking-widest text-xs">Strategy Modeling</h5>
                  <p className="text-gray-500 text-sm mt-2 max-w-[200px]">Compare multiple crops to find the best yield strategy for this season.</p>
                </div>
              </div>
            )}
          </AnimatePresence>

          {/* Market Performance Chart */}
          <section className="bg-white p-8 rounded-[40px] border border-gray-100 mb-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
              <div>
                <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2">
                  <LineChartIcon className="text-blue-600 w-5 h-5" /> {t.performanceIndex}
                </h3>
                <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">{t.volatilityAnalysis}</p>
              </div>
              
              <div className="flex bg-gray-100 p-1.5 rounded-2xl gap-1">
                {(['weekly', 'monthly', 'quarterly'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeframe(tf)}
                    className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                      timeframe === tf 
                        ? 'bg-white text-gray-900 shadow-sm' 
                        : 'text-gray-400 hover:text-gray-600'
                    }`}
                  >
                    {t[tf]}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
              {[
                { key: 'wheat', color: 'bg-amber-500', name: language === 'en' ? 'Wheat' : 'கோதுமை' },
                { key: 'corn', color: 'bg-yellow-500', name: language === 'en' ? 'Corn' : 'சோளம்' },
                { key: 'rice', color: 'bg-blue-300', name: language === 'en' ? 'Rice' : 'அரிசி' },
                { key: 'soybeans', color: 'bg-green-500', name: language === 'en' ? 'Soybeans' : 'சோயாபீன்ஸ்' },
                { key: 'avg', color: 'bg-gray-400', name: language === 'en' ? 'Market Avg' : 'சந்தை சராசரி' },
              ].map((item) => (
                <div key={item.key} className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-xl border border-gray-100">
                  <div className={`w-3 h-3 rounded-full ${item.color}`} />
                  <span className="text-[10px] font-black uppercase text-gray-500 tracking-widest truncate">{item.name}</span>
                </div>
              ))}
            </div>

            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={HISTORICAL_DATA[timeframe]}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis 
                    dataKey="label" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 900, fill: '#9ca3af' }}
                    dy={16}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 900, fill: '#9ca3af' }}
                    tickFormatter={(value) => `$${value}`}
                  />
                  <Tooltip content={<CustomTooltip language={language} />} />
                  <Brush 
                    dataKey="label" 
                    height={40} 
                    stroke="#e5e7eb" 
                    fill="#f9fafb"
                    gap={10}
                    travellerWidth={10}
                  >
                    <LineChart>
                      <Line dataKey="avg" stroke="#9ca3af" strokeWidth={1} dot={false} />
                    </LineChart>
                  </Brush>
                  <Line 
                    type="monotone" 
                    name={language === 'en' ? 'Wheat' : 'கோதுமை'}
                    dataKey="wheat" 
                    stroke="#f59e0b" 
                    strokeWidth={4} 
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line 
                    type="monotone" 
                    name={language === 'en' ? 'Corn' : 'சோளம்'}
                    dataKey="corn" 
                    stroke="#eab308" 
                    strokeWidth={4} 
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line 
                    type="monotone" 
                    name={language === 'en' ? 'Rice' : 'அரிசி'}
                    dataKey="rice" 
                    stroke="#93c5fd" 
                    strokeWidth={4} 
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line 
                    type="monotone" 
                    name={language === 'en' ? 'Soybeans' : 'சோயாபீன்ஸ்'}
                    dataKey="soybeans" 
                    stroke="#22c55e" 
                    strokeWidth={4} 
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                  <Line 
                    type="monotone" 
                    name={language === 'en' ? 'Market Avg' : 'சந்தை சராசரி'}
                    dataKey="avg" 
                    stroke="#9ca3af" 
                    strokeWidth={2} 
                    strokeDasharray="5 5"
                    dot={false}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </section>

          {/* Quick Stats Grid */}
          <section className="bg-white p-8 rounded-[40px] border border-gray-100">
             <div className="flex items-center justify-between mb-8">
               <h3 className="text-lg font-black uppercase tracking-widest flex items-center gap-2">
                 <div className="w-2 h-6 bg-amber-500 rounded-full" />
                 {t.emergingTrends}
               </h3>
               <button className="text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-gray-600 underline underline-offset-4">{t.viewAll}</button>
             </div>
             <div className="space-y-4">
                {[
                  { topic: 'EU Drought impact on Barley', trend: 'Critical', impact: 'High Price Pressure' },
                  { topic: 'South American Soy Supply', trend: 'Increasing', impact: 'Moderate Stability' },
                  { topic: 'Global Fertilizer Cost Offset', trend: 'Decreasing', impact: 'Lower Input Costs' },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 rounded-2xl hover:bg-gray-50 transition-colors group cursor-pointer border border-transparent hover:border-gray-100">
                    <div>
                      <p className="font-bold text-gray-900 group-hover:text-amber-600 transition-colors">{item.topic}</p>
                      <p className="text-[10px] uppercase font-black tracking-widest text-gray-400 mt-1">{item.trend}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-xs font-bold text-gray-500">{item.impact}</span>
                      <ChevronRight className="w-4 h-4 text-gray-300" />
                    </div>
                  </div>
                ))}
             </div>
          </section>
        </div>
      </div>
    </motion.div>
  );
}
