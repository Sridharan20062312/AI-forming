import React, { useState, useRef } from 'react';
import { FlaskConical, Beaker, MapPin, Loader2, Wand2, ArrowRight, Table, Activity, Camera, Upload, Trash2, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ComposedChart,
  Legend,
  Line
} from 'recharts';
import { getSoilRecommendation, analyzeSoilImage } from '../services/gemini';
import { translations, type Language } from '../lib/i18n';

interface SoilAdvisorProps {
  language: Language;
}

export function SoilAdvisor({ language }: SoilAdvisorProps) {
  const t = translations[language].soil;
  const [mode, setMode] = useState<'lab' | 'visual'>('lab');
  const [params, setParams] = useState({
    ph: '',
    nitrogen: '',
    phosphorus: '',
    potassium: '',
    moisture: '',
    location: ''
  });
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const chartData = [
    { name: 'N', nutrient: Number(params.nitrogen) || 0, moisture: Number(params.moisture) || 0 },
    { name: 'P', nutrient: Number(params.phosphorus) || 0, moisture: Number(params.moisture) || 0 },
    { name: 'K', nutrient: Number(params.potassium) || 0, moisture: Number(params.moisture) || 0 },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAnalyzing(true);
    setResult(null);
    try {
      const recommendation = await getSoilRecommendation(params, language);
      setResult(recommendation || 'Analysis failed.');
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleVisualAnalyze = async () => {
    if (!image) return;
    setIsAnalyzing(true);
    setResult(null);
    try {
      const base64Data = image.split(',')[1];
      const analysisResult = await analyzeSoilImage(base64Data, language);
      setResult(analysisResult || 'No analysis could be generated.');
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setParams({ ...params, [e.target.name]: e.target.value });
  };

  const resetVisual = () => {
    setImage(null);
    setResult(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto space-y-8"
    >
      <header className="border-b border-gray-200 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-4xl font-black tracking-tighter text-gray-900 uppercase">{t.title}</h2>
          <p className="text-gray-500 font-medium mt-1">{t.subtitle}</p>
        </div>
        <div className="flex bg-gray-100 p-1.5 rounded-2xl">
          <button 
            onClick={() => { setMode('lab'); setResult(null); }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${mode === 'lab' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
          >
            {t.useLabMode}
          </button>
          <button 
            onClick={() => { setMode('visual'); setResult(null); }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${mode === 'visual' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
          >
            {t.useVisualMode}
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Form or Camera Section */}
        <div className="lg:col-span-1 border border-gray-100 bg-white p-8 rounded-[40px] shadow-sm">
          {mode === 'lab' ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-black uppercase tracking-widest text-gray-400 flex items-center gap-2">
                  <Beaker className="w-4 h-4" /> {t.labParams}
                </h3>
                
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1.5 ml-1">{t.ph}</label>
                    <input 
                      type="number" step="0.1" name="ph" value={params.ph} onChange={handleChange} required
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white p-4 rounded-2xl outline-none transition-all font-bold placeholder:font-medium"
                      placeholder="e.g. 6.5"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1.5 ml-1">N (PPM)</label>
                      <input 
                        type="number" name="nitrogen" value={params.nitrogen} onChange={handleChange} required
                        className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white py-4 text-center rounded-2xl outline-none transition-all font-bold"
                        placeholder="N"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1.5 ml-1">P (PPM)</label>
                      <input 
                        type="number" name="phosphorus" value={params.phosphorus} onChange={handleChange} required
                        className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white py-4 text-center rounded-2xl outline-none transition-all font-bold"
                        placeholder="P"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1.5 ml-1">K (PPM)</label>
                      <input 
                        type="number" name="potassium" value={params.potassium} onChange={handleChange} required
                        className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white py-4 text-center rounded-2xl outline-none transition-all font-bold"
                        placeholder="K"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1.5 ml-1">{t.moisture}</label>
                    <input 
                      type="number" name="moisture" value={params.moisture} onChange={handleChange} required
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white p-4 rounded-2xl outline-none transition-all font-bold"
                      placeholder="e.g. 35"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1.5 ml-1 flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {t.location}
                    </label>
                    <input 
                      type="text" name="location" value={params.location} onChange={handleChange} required
                      className="w-full bg-gray-50 border-2 border-transparent focus:border-green-500 focus:bg-white p-4 rounded-2xl outline-none transition-all font-bold"
                      placeholder="e.g. Central Valley, CA"
                    />
                  </div>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isAnalyzing}
                className="w-full bg-[#1A1A1A] hover:bg-black text-white py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-3 transition-transform active:scale-95 disabled:opacity-50"
              >
                {isAnalyzing ? <Loader2 className="animate-spin w-5 h-5" /> : <Wand2 className="w-5 h-5" />}
                {isAnalyzing ? (language === 'en' ? 'Processing...' : 'செயல்படுகிறது...') : t.getRecommendation}
              </button>
            </form>
          ) : (
            <div className="space-y-6">
               <h3 className="text-sm font-black uppercase tracking-widest text-gray-400 flex items-center gap-2">
                <Camera className="w-4 h-4" /> {t.visualScan}
              </h3>

              {!image ? (
                <div className="space-y-4">
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="aspect-square rounded-[32px] border-4 border-dashed border-gray-100 bg-gray-50 flex flex-col items-center justify-center text-center p-6 cursor-pointer hover:border-green-200 hover:bg-green-50/30 transition-all group"
                  >
                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-sm mb-4 group-hover:scale-110 transition-transform">
                      <Upload className="text-gray-300 w-8 h-8 group-hover:text-green-500 transition-colors" />
                    </div>
                    <p className="text-xs font-black uppercase tracking-widest text-gray-400 leading-relaxed px-4">{t.visualScanSub}</p>
                  </div>
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full bg-gray-100 hover:bg-gray-200 text-gray-600 py-4 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition-colors"
                  >
                    <Upload className="w-4 h-4" /> {t.uploadSoil}
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="relative aspect-square rounded-[32px] overflow-hidden border-4 border-white shadow-lg">
                    <img src={image} alt="Soil scan" className="w-full h-full object-cover" />
                    <button 
                      onClick={resetVisual}
                      className="absolute top-4 right-4 bg-white/90 p-2 rounded-xl text-red-500 shadow-sm hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  <button 
                    onClick={handleVisualAnalyze}
                    disabled={isAnalyzing}
                    className="w-full bg-green-600 hover:bg-green-700 text-white py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-3 transition-all active:scale-95 disabled:opacity-50"
                  >
                    {isAnalyzing ? <Loader2 className="animate-spin w-5 h-5" /> : <Wand2 className="w-5 h-5" />}
                    {isAnalyzing ? (language === 'en' ? 'Scanning...' : 'ஸ்கேன் செய்கிறது...') : t.runSoilAnalysis}
                  </button>
                </div>
              )}
              <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
            </div>
          )}
        </div>

        {/* Output Section */}
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {isAnalyzing ? (
              <motion.div 
                key="analyzing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-white rounded-[40px] border border-gray-100 h-full p-12 flex flex-col items-center justify-center text-center"
              >
                 <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-6">
                   <FlaskConical className="w-10 h-10 text-green-600 animate-bounce" />
                 </div>
                 <h4 className="text-2xl font-black mb-2 uppercase tracking-tighter">
                   {mode === 'lab' ? t.analyzing : t.scanning}
                 </h4>
                 <p className="text-gray-400 font-medium max-w-sm">{t.analyzingSub}</p>
              </motion.div>
            ) : result ? (
              <motion.div 
                key="result"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-[40px] border border-gray-100 shadow-xl overflow-hidden flex flex-col h-full"
              >
                <div className={`p-6 ${mode === 'lab' ? 'bg-indigo-600' : 'bg-green-600'} text-white flex items-center justify-between transition-colors`}>
                  <div className="flex items-center gap-3">
                    {mode === 'lab' ? <FlaskConical className="w-6 h-6" /> : <Camera className="w-6 h-6" />}
                    <span className="font-black uppercase tracking-widest">
                      {mode === 'lab' ? t.reportTitle : t.scanComplete}
                    </span>
                  </div>
                  <div className="text-[10px] font-black uppercase tracking-widest px-2 py-1 bg-white/20 rounded">
                    {mode === 'lab' ? 'Lab Grade' : 'Visual Est'}
                  </div>
                </div>
                <div className="p-8 overflow-y-auto max-h-[800px] prose prose-indigo max-w-none">
                  <div className="markdown-body">
                    <ReactMarkdown>{result}</ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="bg-gray-50 border-2 border-dashed border-gray-200 rounded-[40px] h-full flex flex-col items-center justify-center p-12 text-center text-gray-400">
                {mode === 'lab' ? (
                  <>
                    <Table className="w-16 h-16 text-gray-200 mb-4" />
                    <h4 className="text-gray-400 font-black uppercase tracking-widest">{t.emptyState}</h4>
                    <p className="text-gray-300 text-sm mt-2 max-w-xs font-medium">{t.emptyStateSub}</p>
                  </>
                ) : (
                  <>
                    <Camera className="w-16 h-16 text-gray-200 mb-4" />
                    <h4 className="text-gray-400 font-black uppercase tracking-widest">{language === 'en' ? 'Awaiting Soil Image' : 'மண் படத்திற்காகக் காத்திருக்கிறது'}</h4>
                    <p className="text-gray-300 text-sm mt-2 max-w-xs font-medium">{language === 'en' ? 'Take a clear photo of your field soil for a quick visual health estimate.' : 'விரைவான காட்சி ஆரோக்கிய மதிப்பீட்டிற்கு உங்கள் வயல் மண்ணின் தெளிவான புகைப்படத்தை எடுக்கவும்.'}</p>
                  </>
                )}
                <div className="mt-8 flex gap-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-12 h-1.5 bg-gray-200 rounded-full" />
                  ))}
                </div>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Visual Workspace Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[40px] border border-gray-100 p-8 shadow-sm"
      >
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-2">
              <Activity className="text-green-600 w-5 h-5" /> {t.visualization}
            </h3>
            <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">{t.spectralData}</p>
          </div>
          <div className="flex gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 rounded-xl border border-green-100">
               <div className="w-2.5 h-2.5 bg-green-600 rounded-sm" />
               <span className="text-[10px] font-black uppercase text-green-700 tracking-wider">{t.npkLevels}</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-50 rounded-xl border border-blue-100">
               <div className="w-2.5 h-2.5 bg-blue-500 rounded-full" />
               <span className="text-[10px] font-black uppercase text-blue-700 tracking-wider">{t.moistureOffset}</span>
            </div>
          </div>
        </div>

        <div className="h-[350px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9CA3AF', fontWeight: 700, fontSize: 12 }}
                dy={10}
              />
              <YAxis 
                yAxisId="left"
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9CA3AF', fontWeight: 500, fontSize: 11 }}
              />
              <YAxis 
                yAxisId="right" 
                orientation="right" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#9CA3AF', fontWeight: 500, fontSize: 11 }}
              />
              <Tooltip 
                cursor={{ fill: '#F9FAFB' }}
                contentStyle={{ 
                  borderRadius: '16px', 
                  border: 'none', 
                  boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                  padding: '12px'
                }}
                itemStyle={{ fontWeight: 700, fontSize: '12px' }}
              />
              <Bar 
                yAxisId="left"
                dataKey="nutrient" 
                fill="#16A34A" 
                radius={[8, 8, 0, 0]} 
                barSize={60} 
                animationDuration={1500}
              />
              <Line 
                yAxisId="right"
                type="monotone" 
                dataKey="moisture" 
                stroke="#3B82F6" 
                strokeWidth={4} 
                dot={{ r: 6, fill: '#3B82F6', strokeWidth: 2, stroke: '#fff' }}
                activeDot={{ r: 8, strokeWidth: 0 }}
                animationDuration={2000}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </motion.div>
  );
}
