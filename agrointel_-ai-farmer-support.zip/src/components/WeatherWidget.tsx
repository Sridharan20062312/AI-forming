import React, { useState, useEffect } from 'react';
import { CloudRain, Sun, Wind, Droplets, MapPin, Thermometer, X, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { translations, type Language } from '../lib/i18n';

interface WeatherWidgetProps {
  language: Language;
}

export function WeatherWidget({ language }: WeatherWidgetProps) {
  const t = translations[language].weather;
  const [weather, setWeather] = useState({
    temp: '24°C',
    status: language === 'en' ? 'Partly Cloudy' : 'ஓரளவு மேகமூட்டம்',
    humidity: '62%',
    wind: '12 km/h',
    rainChance: '5%',
    location: t.location
  });

  const [showAlert, setShowAlert] = useState(true);

  // Parse rain chance to number
  const rainProbability = parseInt(weather.rainChance);
  const isHighRainRisk = rainProbability > 50;

  useEffect(() => {
    setWeather(prev => ({
      ...prev,
      status: language === 'en' ? 'Partly Cloudy' : 'ஓரளவு மேகமூட்டம்',
      location: t.location
    }));
  }, [language]);

  return (
    <div className="bg-gradient-to-br from-green-600 to-green-800 p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden group">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:rotate-12 transition-transform duration-700">
        <Sun className="w-32 h-32" />
      </div>
      
      <div className="relative z-10">
        <AnimatePresence>
          {isHighRainRisk && showAlert && (
            <motion.div 
              initial={{ height: 0, opacity: 0, marginBottom: 0 }}
              animate={{ height: 'auto', opacity: 1, marginBottom: 24 }}
              exit={{ height: 0, opacity: 0, marginBottom: 0 }}
              className="bg-amber-400 text-amber-950 p-4 rounded-3xl flex items-start gap-3 shadow-xl relative overflow-hidden group/alert border border-amber-300"
            >
              <div className="p-2 bg-amber-900/10 rounded-xl shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1 pr-6">
                <p className="text-[10px] font-black uppercase tracking-widest leading-none mb-1 opacity-70">{t.warning}</p>
                <p className="text-sm font-black leading-tight">{t.incomingRain} ({weather.rainChance})</p>
                <p className="text-[10px] font-medium mt-1 leading-relaxed opacity-80">{t.rainTip}</p>
              </div>
              <button 
                onClick={() => setShowAlert(false)}
                className="absolute top-3 right-3 p-1.5 hover:bg-black/10 rounded-xl transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-8">
          <div className="flex justify-between items-start">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-xs font-black uppercase tracking-widest bg-white/20 px-3 py-1.5 rounded-full backdrop-blur-md self-start">
                <MapPin className="w-3 h-3" /> {weather.location}
              </div>
              {/* Simulation Toggle for Demo */}
              <button 
                onClick={() => {
                  const newRain = weather.rainChance === '5%' ? '75%' : '5%';
                  setWeather(w => ({ ...w, rainChance: newRain }));
                  if (newRain === '75%') setShowAlert(true);
                }}
                className="text-[10px] font-black uppercase tracking-widest text-green-200 hover:text-white transition-colors flex items-center gap-1"
              >
                Toggle Demo Rain <Wind className="w-3 h-3" />
              </button>
            </div>
            <div className="text-right">
               <p className="text-4xl font-black">{weather.temp}</p>
               <p className="text-xs font-bold opacity-80 uppercase tracking-widest">{weather.status}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/10 p-4 rounded-3xl backdrop-blur-sm flex items-center gap-3 border border-white/10">
              <Droplets className="w-5 h-5 text-blue-300" />
              <div>
                <p className="text-[10px] font-black uppercase opacity-60">{t.humidity}</p>
                <p className="font-black text-sm">{weather.humidity}</p>
              </div>
            </div>
            <div className="bg-white/10 p-4 rounded-3xl backdrop-blur-sm flex items-center gap-3 border border-white/10">
              <Wind className="w-5 h-5 text-gray-300" />
              <div>
                <p className="text-[10px] font-black uppercase opacity-60">{t.wind}</p>
                <p className="font-black text-sm">{weather.wind}</p>
              </div>
            </div>
            <div className={cn(
              "p-4 rounded-3xl backdrop-blur-sm flex items-center gap-3 border transition-colors",
              isHighRainRisk ? "bg-blue-500/20 border-blue-400" : "bg-white/10 border-white/10"
            )}>
              <CloudRain className={cn("w-5 h-5", isHighRainRisk ? "text-blue-300" : "text-sky-400")} />
              <div>
                <p className="text-[10px] font-black uppercase opacity-60">{t.rain}</p>
                <p className="font-black text-sm">{weather.rainChance}</p>
              </div>
            </div>
            <div className="bg-white/10 p-4 rounded-3xl backdrop-blur-sm flex items-center gap-3 border border-white/10">
              <Thermometer className="w-5 h-5 text-orange-300" />
              <div>
                <p className="text-[10px] font-black uppercase opacity-60">{t.comfort}</p>
                <p className="font-black text-sm">{language === 'en' ? 'High' : 'அதிகம்'}</p>
              </div>
            </div>
          </div>

          <button className="w-full py-4 bg-white text-green-800 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-green-50 transition-colors shadow-lg active:scale-95">
            {t.forecast}
          </button>
        </div>
      </div>
    </div>
  );
}

// Utility for classes
function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}


